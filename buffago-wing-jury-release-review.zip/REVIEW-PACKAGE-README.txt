BUFFAGO ? PACKAGING ONLY, NOT DEPLOYMENT AUTHORIZATION

Start with docs/buffago-wing-jury-go-live-handoff.md and the current go-live artifact inventory.
Decision A concerns feature independence; documented remaining approvals/acceptance still apply.
Exact source and bundled three-function candidates are included, plus scoped runtime config and frozen lock.
Production delete-account replacement, the already-deployed permission hotfix SQL, credentials, .env files,
node_modules, production connection material, native builds and unrelated artifacts are excluded.
Older evidence statements are dated provenance; the current go-live handoff supersedes old deletion gates.

Missing evidence (not fabricated): full matching production DDL-handler source/compatibility acceptance,
and actual hosted gateway/rate-limit/Storage/Auth acceptance are not locally available in the existing packet.
Existing R3 summaries, correspondence, metadata and local Edge acceptance are included.

This ZIP is for review, not a standalone executable production environment. The unchanged adapter requires
externally provisioned approval/trust/credentials/psql and original repository context. verify-package.mjs
reads the historical migration directory to check filename ordering: history SQL is deliberately excluded;
use the original repository and accepted history documents, never replay historical migrations from this ZIP.
Deno executable/cache are not included; the inventory pins the tested runtime and lockfile.

review-package-manifest.json inventories and hashes every copied file; supplemental unchanged documents
not already indexed by release manifests are identified explicitly. ZIP content was reread and verified.
